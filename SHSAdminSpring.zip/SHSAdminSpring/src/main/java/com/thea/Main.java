package com.thea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

/**
 * Created by Thea on 15/07/2017.
 */
public class Main {
    public static  void main (String[] args){
        SpringApplication.run(Main.class, args);

    }
}
